10 DARK FUTURISTIC PORTFOLIO LANDING PAGES

Each folder contains an index.html and README.txt.
They are responsive, self-contained and designed to be easy to customize.
For a $1 product, you can package these as templates, but check the license/terms of any marketplace you use.
