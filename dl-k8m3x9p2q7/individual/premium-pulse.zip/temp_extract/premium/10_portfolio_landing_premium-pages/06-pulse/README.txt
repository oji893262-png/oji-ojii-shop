PREMIUM TEMPLATE — Pulse

Advanced features:
• Canvas particle/network field with pointer interaction
• Scroll reveal via IntersectionObserver
• 3D pointer-reactive project cards
• Glassmorphism + backdrop blur
• Animated gradient typography
• Responsive/mobile-first CSS
• Reduced-motion accessibility fallback
• Command-style page navigation
• No framework/build step required

Customize index.html: name, text, projects, stats and email.
