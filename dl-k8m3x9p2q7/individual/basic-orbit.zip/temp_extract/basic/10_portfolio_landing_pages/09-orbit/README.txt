CUSTOMIZE THIS TEMPLATE

1. Open index.html.
2. Replace YOUR.NAME / YOUR NAME.
3. Replace project names, descriptions and stats.
4. Replace you@example.com with your contact email.
5. Upload index.html to your hosting.

This template is intentionally self-contained: no frameworks or external assets required.
